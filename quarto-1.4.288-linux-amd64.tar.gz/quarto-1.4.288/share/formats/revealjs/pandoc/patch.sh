#!/bin/bash
set -e

patch -u revealjs.template -i reveal.patch -o template.revealjs