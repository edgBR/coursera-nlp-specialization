
# there is no equivalent of %reset magic in Julia, in fact in Julia there is no 
# way to clear the workspace programatically, see discussion thread at:
# https://discourse.julialang.org/t/how-to-clear-workspace-variables/44095